import { Outlet, Link, useLocation } from "react-router";
import { 
  LayoutDashboard, 
  Dumbbell, 
  UtensilsCrossed, 
  Bot, 
  TrendingUp, 
  User, 
  Settings as SettingsIcon,
  Bell,
  Flame
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "../ui/avatar";
import { Badge } from "../ui/badge";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Workout Plan", href: "/workout", icon: Dumbbell },
  { name: "Meal Plan", href: "/meals", icon: UtensilsCrossed },
  { name: "AI Coach (AROMI)", href: "/coach", icon: Bot },
  { name: "Progress Tracking", href: "/progress", icon: TrendingUp },
  { name: "Health Profile", href: "/profile", icon: User },
  { name: "Settings", href: "/settings", icon: SettingsIcon },
];

export function RootLayout() {
  const location = useLocation();

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-border flex flex-col">
        {/* Logo */}
        <div className="h-16 flex items-center px-6 border-b border-border">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-secondary rounded-lg flex items-center justify-center">
              <Dumbbell className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-[15px] font-semibold">ArogyaMitra</h1>
              <p className="text-[10px] text-muted-foreground">AI Wellness Coach</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navigation.map((item) => {
            const isActive = location.pathname === item.href;
            return (
              <Link
                key={item.name}
                to={item.href}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                  isActive
                    ? "bg-primary text-white"
                    : "text-foreground hover:bg-muted"
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="text-[14px]">{item.name}</span>
              </Link>
            );
          })}
        </nav>

        {/* User Section */}
        <div className="p-4 border-t border-border">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
            <Avatar className="w-10 h-10">
              <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Priya" />
              <AvatarFallback>PS</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-[13px] font-medium truncate">Priya Sharma</p>
              <p className="text-[11px] text-muted-foreground">Premium Plan</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Navbar */}
        <header className="h-16 bg-white border-b border-border flex items-center justify-between px-6">
          <div className="flex items-center gap-4">
            <h2 className="text-[15px] font-semibold">
              {navigation.find((item) => item.href === location.pathname)?.name || "Dashboard"}
            </h2>
          </div>

          <div className="flex items-center gap-4">
            {/* Streak */}
            <div className="flex items-center gap-2 px-3 py-1.5 bg-accent/10 rounded-lg">
              <Flame className="w-4 h-4 text-accent" />
              <span className="text-[13px] font-medium">7 Day Streak</span>
            </div>

            {/* Daily Progress */}
            <div className="flex items-center gap-2 px-3 py-1.5 bg-primary/10 rounded-lg">
              <TrendingUp className="w-4 h-4 text-primary" />
              <span className="text-[13px] font-medium">75% Daily Goal</span>
            </div>

            {/* Notifications */}
            <button className="relative p-2 hover:bg-muted rounded-lg transition-colors">
              <Bell className="w-5 h-5" />
              <Badge className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center p-0 text-[10px] bg-accent">
                3
              </Badge>
            </button>

            {/* User Avatar */}
            <Avatar className="w-9 h-9 cursor-pointer">
              <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Priya" />
              <AvatarFallback>PS</AvatarFallback>
            </Avatar>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
