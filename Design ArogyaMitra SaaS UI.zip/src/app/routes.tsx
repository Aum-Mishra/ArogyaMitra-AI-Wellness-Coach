import { createBrowserRouter } from "react-router";
import { RootLayout } from "./components/layout/RootLayout";
import { Dashboard } from "./pages/Dashboard";
import { WorkoutPlan } from "./pages/WorkoutPlan";
import { MealPlan } from "./pages/MealPlan";
import { AICoach } from "./pages/AICoach";
import { Progress } from "./pages/Progress";
import { HealthProfile } from "./pages/HealthProfile";
import { Settings } from "./pages/Settings";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: RootLayout,
    children: [
      { index: true, Component: Dashboard },
      { path: "workout", Component: WorkoutPlan },
      { path: "meals", Component: MealPlan },
      { path: "coach", Component: AICoach },
      { path: "progress", Component: Progress },
      { path: "profile", Component: HealthProfile },
      { path: "settings", Component: Settings },
    ],
  },
]);
