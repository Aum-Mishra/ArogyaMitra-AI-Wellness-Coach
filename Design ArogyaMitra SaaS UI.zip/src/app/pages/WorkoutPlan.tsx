import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { WorkoutItem } from "../components/shared/ProgressComponents";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { CheckCircle2, Calendar, Trophy } from "lucide-react";

interface Exercise {
  id: string;
  name: string;
  details: string;
}

interface DayWorkout {
  day: number;
  title: string;
  duration: string;
  exercises: Exercise[];
}

const weeklyWorkouts: DayWorkout[] = [
  {
    day: 1,
    title: "Upper Body Strength",
    duration: "35 minutes",
    exercises: [
      { id: "1-1", name: "Warmup – Arm Circles", details: "2 minutes" },
      { id: "1-2", name: "Push-ups", details: "3 sets × 10 reps" },
      { id: "1-3", name: "Dumbbell Rows", details: "3 sets × 12 reps" },
      { id: "1-4", name: "Shoulder Press", details: "3 sets × 10 reps" },
      { id: "1-5", name: "Tricep Dips", details: "3 sets × 12 reps" },
      { id: "1-6", name: "Cooldown Stretch", details: "5 minutes" },
    ],
  },
  {
    day: 2,
    title: "Lower Body Power",
    duration: "40 minutes",
    exercises: [
      { id: "2-1", name: "Warmup – Leg Swings", details: "3 minutes" },
      { id: "2-2", name: "Squats", details: "4 sets × 15 reps" },
      { id: "2-3", name: "Lunges", details: "3 sets × 12 reps each leg" },
      { id: "2-4", name: "Deadlifts", details: "3 sets × 10 reps" },
      { id: "2-5", name: "Calf Raises", details: "3 sets × 20 reps" },
      { id: "2-6", name: "Cooldown Stretch", details: "5 minutes" },
    ],
  },
  {
    day: 3,
    title: "Core & Cardio",
    duration: "30 minutes",
    exercises: [
      { id: "3-1", name: "Warmup – Jumping Jacks", details: "3 minutes" },
      { id: "3-2", name: "Plank", details: "3 sets × 45 seconds" },
      { id: "3-3", name: "Russian Twists", details: "3 sets × 20 reps" },
      { id: "3-4", name: "Mountain Climbers", details: "3 sets × 30 seconds" },
      { id: "3-5", name: "Burpees", details: "3 sets × 10 reps" },
      { id: "3-6", name: "Cooldown Walk", details: "5 minutes" },
    ],
  },
  {
    day: 4,
    title: "Active Recovery",
    duration: "25 minutes",
    exercises: [
      { id: "4-1", name: "Light Walking", details: "10 minutes" },
      { id: "4-2", name: "Yoga Flow", details: "10 minutes" },
      { id: "4-3", name: "Full Body Stretch", details: "5 minutes" },
    ],
  },
  {
    day: 5,
    title: "Full Body Circuit",
    duration: "45 minutes",
    exercises: [
      { id: "5-1", name: "Warmup – Dynamic Stretches", details: "5 minutes" },
      { id: "5-2", name: "Push-ups", details: "3 sets × 12 reps" },
      { id: "5-3", name: "Squats", details: "3 sets × 15 reps" },
      { id: "5-4", name: "Plank", details: "3 sets × 1 minute" },
      { id: "5-5", name: "Jumping Jacks", details: "3 sets × 30 seconds" },
      { id: "5-6", name: "Superman Hold", details: "3 sets × 30 seconds" },
      { id: "5-7", name: "Cooldown Stretch", details: "5 minutes" },
    ],
  },
  {
    day: 6,
    title: "HIIT Training",
    duration: "30 minutes",
    exercises: [
      { id: "6-1", name: "Warmup – High Knees", details: "2 minutes" },
      { id: "6-2", name: "Burpees", details: "4 sets × 10 reps" },
      { id: "6-3", name: "Jump Squats", details: "4 sets × 12 reps" },
      { id: "6-4", name: "Mountain Climbers", details: "4 sets × 30 seconds" },
      { id: "6-5", name: "Box Jumps", details: "4 sets × 10 reps" },
      { id: "6-6", name: "Cooldown Walk", details: "5 minutes" },
    ],
  },
  {
    day: 7,
    title: "Rest & Mobility",
    duration: "20 minutes",
    exercises: [
      { id: "7-1", name: "Gentle Yoga", details: "10 minutes" },
      { id: "7-2", name: "Foam Rolling", details: "5 minutes" },
      { id: "7-3", name: "Meditation", details: "5 minutes" },
    ],
  },
];

export function WorkoutPlan() {
  const [workoutCompletions, setWorkoutCompletions] = useState<Record<string, boolean>>({});

  const toggleExercise = (exerciseId: string) => {
    setWorkoutCompletions((prev) => ({
      ...prev,
      [exerciseId]: !prev[exerciseId],
    }));
  };

  const getDayCompletion = (day: DayWorkout) => {
    const completed = day.exercises.filter((ex) => workoutCompletions[ex.id]).length;
    return { completed, total: day.exercises.length };
  };

  const totalCompleted = Object.values(workoutCompletions).filter(Boolean).length;
  const totalExercises = weeklyWorkouts.reduce((sum, day) => sum + day.exercises.length, 0);

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-[24px] font-semibold">7-Day Workout Plan</h1>
          <p className="text-muted-foreground text-[14px]">
            AI-generated plan tailored to your fitness level and goals
          </p>
        </div>
        <Card className="md:w-auto bg-gradient-to-br from-primary to-secondary text-white border-none">
          <CardContent className="p-4 flex items-center gap-3">
            <Trophy className="w-8 h-8" />
            <div>
              <p className="text-[20px] font-semibold">
                {totalCompleted} / {totalExercises}
              </p>
              <p className="text-[12px] opacity-90">Exercises Completed</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-primary" />
            Weekly Overview
          </CardTitle>
          <CardDescription>Track your progress across the week</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {weeklyWorkouts.map((day) => {
              const { completed, total } = getDayCompletion(day);
              const isCompleted = completed === total;
              return (
                <div
                  key={day.day}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    isCompleted
                      ? "bg-primary/10 border-primary"
                      : "bg-white border-border hover:border-primary/40"
                  }`}
                >
                  <div className="text-center">
                    <p className="text-[11px] text-muted-foreground font-medium">Day {day.day}</p>
                    {isCompleted && <CheckCircle2 className="w-6 h-6 text-primary mx-auto mt-1" />}
                    {!isCompleted && (
                      <div className="mt-1">
                        <p className="text-[16px] font-semibold">{completed}</p>
                        <p className="text-[10px] text-muted-foreground">/{total}</p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Workout Days */}
      <Tabs defaultValue="1" className="w-full">
        <TabsList className="w-full justify-start overflow-x-auto flex-wrap h-auto">
          {weeklyWorkouts.map((day) => {
            const { completed, total } = getDayCompletion(day);
            const isCompleted = completed === total;
            return (
              <TabsTrigger key={day.day} value={day.day.toString()} className="relative">
                Day {day.day}
                {isCompleted && (
                  <CheckCircle2 className="w-4 h-4 text-primary absolute -top-1 -right-1" />
                )}
              </TabsTrigger>
            );
          })}
        </TabsList>

        {weeklyWorkouts.map((day) => {
          const { completed, total } = getDayCompletion(day);
          return (
            <TabsContent key={day.day} value={day.day.toString()} className="space-y-4 mt-6">
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-[18px]">{day.title}</CardTitle>
                      <CardDescription>{day.duration}</CardDescription>
                    </div>
                    <Badge
                      variant={completed === total ? "default" : "secondary"}
                      className={completed === total ? "bg-primary" : ""}
                    >
                      {completed} / {total} Complete
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {day.exercises.map((exercise) => (
                    <WorkoutItem
                      key={exercise.id}
                      exercise={exercise.name}
                      details={exercise.details}
                      completed={!!workoutCompletions[exercise.id]}
                      onToggle={() => toggleExercise(exercise.id)}
                      showVideo
                    />
                  ))}

                  {completed === total && (
                    <div className="mt-6 p-4 bg-primary/10 border border-primary/20 rounded-lg flex items-center gap-3">
                      <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center">
                        <Trophy className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-semibold text-primary">Day {day.day} Complete!</p>
                        <p className="text-[13px] text-muted-foreground">
                          Great job! Keep up the momentum.
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          );
        })}
      </Tabs>
    </div>
  );
}
