import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { CircularProgress, WorkoutItem, MealItem, ProgressBar } from "../components/shared/ProgressComponents";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Activity, Droplets, Footprints, Target, Send, Sparkles, Award } from "lucide-react";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const weeklyCaloriesData = [
  { day: "Mon", burned: 420, consumed: 1800 },
  { day: "Tue", burned: 380, consumed: 1950 },
  { day: "Wed", burned: 450, consumed: 1850 },
  { day: "Thu", burned: 390, consumed: 1900 },
  { day: "Fri", burned: 410, consumed: 1820 },
  { day: "Sat", burned: 520, consumed: 2100 },
  { day: "Sun", burned: 480, consumed: 1880 },
];

const weightProgressData = [
  { week: "Week 1", weight: 72 },
  { week: "Week 2", weight: 71.5 },
  { week: "Week 3", weight: 71 },
  { week: "Week 4", weight: 70.5 },
];

export function Dashboard() {
  const [workoutProgress, setWorkoutProgress] = useState({
    warmup: false,
    pushups: false,
    squats: false,
    plank: false,
  });

  const [mealProgress, setMealProgress] = useState({
    breakfast: false,
    lunch: false,
    snack: false,
    dinner: false,
  });

  const [chatMessage, setChatMessage] = useState("");

  const workoutItems = [
    { key: "warmup", exercise: "Warmup – Jumping Jacks", details: "3 minutes" },
    { key: "pushups", exercise: "Pushups", details: "3 sets × 10 reps" },
    { key: "squats", exercise: "Squats", details: "3 sets × 12 reps" },
    { key: "plank", exercise: "Plank", details: "30 seconds" },
  ];

  const mealItems = [
    { key: "breakfast", meal: "Breakfast", description: "Oats with fruits", calories: 350 },
    { key: "lunch", meal: "Lunch", description: "Dal + Rice + Salad", calories: 520 },
    { key: "snack", meal: "Snack", description: "Yogurt with nuts", calories: 180 },
    { key: "dinner", meal: "Dinner", description: "Paneer curry + roti", calories: 480 },
  ];

  const completedWorkouts = Object.values(workoutProgress).filter(Boolean).length;
  const completedMeals = Object.values(mealProgress).filter(Boolean).length;
  const totalCalories = mealItems.reduce((sum, item) => sum + item.calories, 0);
  const consumedCalories = mealItems
    .filter((item) => mealProgress[item.key as keyof typeof mealProgress])
    .reduce((sum, item) => sum + item.calories, 0);

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Welcome Section */}
      <Card className="bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10 border-none">
        <CardHeader>
          <CardTitle className="text-[20px]">Good Morning, Priya! 🌟</CardTitle>
          <CardDescription>Let's make today count! Here's your wellness summary</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="flex flex-col items-center justify-center p-4 bg-white rounded-xl shadow-sm">
              <CircularProgress value={consumedCalories} max={totalCalories} size={70} label="kcal" />
              <p className="mt-2 text-[12px] text-muted-foreground">Calories Goal</p>
            </div>
            <div className="flex flex-col items-center justify-center p-4 bg-white rounded-xl shadow-sm">
              <CircularProgress 
                value={completedWorkouts} 
                max={4} 
                size={70} 
                color="#60a5fa" 
                label="done" 
              />
              <p className="mt-2 text-[12px] text-muted-foreground">Workout Progress</p>
            </div>
            <div className="flex flex-col items-center justify-center p-4 bg-white rounded-xl shadow-sm">
              <CircularProgress value={6} max={8} size={70} color="#f97316" label="glasses" />
              <p className="mt-2 text-[12px] text-muted-foreground">Water Intake</p>
            </div>
            <div className="flex flex-col items-center justify-center p-4 bg-white rounded-xl shadow-sm">
              <CircularProgress value={7500} max={10000} size={70} color="#8b5cf6" label="steps" />
              <p className="mt-2 text-[12px] text-muted-foreground">Daily Steps</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Today's Workout */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="w-5 h-5 text-primary" />
                  Today's Workout
                </CardTitle>
                <CardDescription>Day 3 Workout – 30 minutes</CardDescription>
              </div>
              <div className="text-right">
                <p className="text-[20px] font-semibold text-primary">{completedWorkouts}/4</p>
                <p className="text-[12px] text-muted-foreground">Completed</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {workoutItems.map((item) => (
              <WorkoutItem
                key={item.key}
                exercise={item.exercise}
                details={item.details}
                completed={workoutProgress[item.key as keyof typeof workoutProgress]}
                onToggle={() =>
                  setWorkoutProgress((prev) => ({
                    ...prev,
                    [item.key]: !prev[item.key as keyof typeof workoutProgress],
                  }))
                }
                showVideo
              />
            ))}
            <ProgressBar
              value={completedWorkouts}
              max={4}
              label="Workout Completion"
              color="bg-primary"
            />
          </CardContent>
        </Card>

        {/* AI Coach Widget */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-secondary" />
              AROMI AI Coach
            </CardTitle>
            <CardDescription>Your personal wellness assistant</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3 max-h-[280px] overflow-y-auto">
              <div className="flex gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-secondary to-primary flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <div className="bg-muted rounded-lg p-3 flex-1">
                  <p className="text-[13px]">
                    Great job on your workout streak! Remember to stay hydrated and get enough rest tonight. 💪
                  </p>
                </div>
              </div>
              <div className="flex gap-2 justify-end">
                <div className="bg-primary text-white rounded-lg p-3 max-w-[80%]">
                  <p className="text-[13px]">I'm traveling for 4 days. What should I do?</p>
                </div>
              </div>
              <div className="flex gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-secondary to-primary flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-4 h-4 text-white" />
                </div>
                <div className="bg-muted rounded-lg p-3 flex-1">
                  <p className="text-[13px]">
                    I've adjusted your plan! Focus on bodyweight exercises: push-ups, squats, and planks. I'll send you a travel-friendly routine. 🎯
                  </p>
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Input
                placeholder="Ask AROMI anything..."
                value={chatMessage}
                onChange={(e) => setChatMessage(e.target.value)}
                className="flex-1"
              />
              <Button size="icon" className="bg-primary hover:bg-primary/90">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Today's Meal Plan */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <Target className="w-5 h-5 text-accent" />
                  Today's Nutrition Plan
                </CardTitle>
                <CardDescription>Track your daily meals</CardDescription>
              </div>
              <div className="text-right">
                <p className="text-[20px] font-semibold text-accent">{consumedCalories}</p>
                <p className="text-[12px] text-muted-foreground">/ {totalCalories} kcal</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-3">
            {mealItems.map((item) => (
              <MealItem
                key={item.key}
                meal={item.meal}
                description={item.description}
                calories={item.calories}
                completed={mealProgress[item.key as keyof typeof mealProgress]}
                onToggle={() =>
                  setMealProgress((prev) => ({
                    ...prev,
                    [item.key]: !prev[item.key as keyof typeof mealProgress],
                  }))
                }
              />
            ))}
            <ProgressBar
              value={consumedCalories}
              max={totalCalories}
              label="Daily Calories"
              color="bg-accent"
            />
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="w-5 h-5 text-primary" />
              Achievements
            </CardTitle>
            <CardDescription>Your recent milestones</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3 p-3 bg-accent/10 rounded-lg">
              <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center">
                <span className="text-[18px]">🏅</span>
              </div>
              <div className="flex-1">
                <p className="text-[13px] font-medium">7 Day Streak</p>
                <p className="text-[11px] text-muted-foreground">Keep it going!</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-primary/10 rounded-lg">
              <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
                <span className="text-[18px]">💪</span>
              </div>
              <div className="flex-1">
                <p className="text-[13px] font-medium">10 Workouts Completed</p>
                <p className="text-[11px] text-muted-foreground">Great progress!</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-secondary/10 rounded-lg">
              <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center">
                <span className="text-[18px]">🥗</span>
              </div>
              <div className="flex-1">
                <p className="text-[13px] font-medium">5 Healthy Days</p>
                <p className="text-[11px] text-muted-foreground">Nutrition on track!</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Weight Progress</CardTitle>
            <CardDescription>Your weight trend over the past month</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={weightProgressData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="week" tick={{ fontSize: 12 }} />
                <YAxis domain={[68, 73]} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="weight"
                  stroke="#10b981"
                  strokeWidth={3}
                  dot={{ fill: "#10b981", r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Weekly Calories</CardTitle>
            <CardDescription>Calories burned vs consumed this week</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={weeklyCaloriesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="day" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Bar dataKey="burned" fill="#10b981" radius={[8, 8, 0, 0]} />
                <Bar dataKey="consumed" fill="#60a5fa" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
