import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Sparkles, Send, Dumbbell, UtensilsCrossed, Heart, TrendingUp } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "../components/ui/avatar";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

const initialMessages: Message[] = [
  {
    id: "1",
    role: "assistant",
    content: "Hello Priya! 👋 I'm AROMI, your AI wellness coach. I'm here to help you with personalized fitness advice, nutrition guidance, and motivation. How can I assist you today?",
    timestamp: new Date(Date.now() - 300000),
  },
];

const quickActions = [
  { icon: Dumbbell, label: "Adjust workout plan", color: "bg-primary" },
  { icon: UtensilsCrossed, label: "Suggest healthy meal", color: "bg-accent" },
  { icon: Heart, label: "Recovery exercises", color: "bg-destructive" },
  { icon: TrendingUp, label: "Track my progress", color: "bg-secondary" },
];

const sampleResponses = [
  "That's a great question! Based on your current fitness level, I recommend focusing on progressive overload. Gradually increase the intensity of your workouts by adding more weight or repetitions each week.",
  "For your travel workout, try this quick 20-minute routine:\n\n1. Push-ups: 3 sets × 12 reps\n2. Bodyweight squats: 3 sets × 15 reps\n3. Plank: 3 sets × 45 seconds\n4. Burpees: 3 sets × 10 reps\n\nNo equipment needed! Perfect for hotel rooms.",
  "Great job on your consistency! Here's a nutritious meal suggestion:\n\nGrilled chicken with quinoa and roasted vegetables:\n- 150g chicken breast (280 kcal)\n- 1 cup quinoa (222 kcal)\n- Mixed veggies (80 kcal)\n\nTotal: ~580 kcal with 45g protein!",
  "Your progress is amazing! You've completed 85% of your workouts this month and maintained a 7-day streak. Keep up the excellent work! 💪",
];

export function AICoach() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputMessage, setInputMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const handleSendMessage = (text?: string) => {
    const messageText = text || inputMessage.trim();
    if (!messageText) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: messageText,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputMessage("");
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const randomResponse = sampleResponses[Math.floor(Math.random() * sampleResponses.length)];
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: randomResponse,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
      setIsTyping(false);
    }, 1500);
  };

  const handleQuickAction = (label: string) => {
    handleSendMessage(label);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="p-6 max-w-[1200px] mx-auto h-[calc(100vh-5rem)]">
      <div className="flex flex-col h-full gap-6">
        {/* Header */}
        <div>
          <h1 className="text-[24px] font-semibold flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-secondary to-primary rounded-full flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            AROMI AI Coach
          </h1>
          <p className="text-muted-foreground text-[14px] mt-1">
            Your 24/7 personal wellness assistant powered by AI
          </p>
        </div>

        <div className="flex-1 grid grid-cols-1 lg:grid-cols-4 gap-6 overflow-hidden">
          {/* Quick Actions Sidebar */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="text-[16px]">Quick Actions</CardTitle>
              <CardDescription className="text-[12px]">Get instant help</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              {quickActions.map((action, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="w-full justify-start gap-2 h-auto py-3"
                  onClick={() => handleQuickAction(action.label)}
                >
                  <div className={`w-8 h-8 ${action.color} rounded-lg flex items-center justify-center`}>
                    <action.icon className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-[13px] text-left">{action.label}</span>
                </Button>
              ))}
            </CardContent>
          </Card>

          {/* Chat Area */}
          <Card className="lg:col-span-3 flex flex-col">
            <CardHeader className="border-b">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-secondary to-primary rounded-full flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <div>
                  <CardTitle className="text-[16px]">Chat with AROMI</CardTitle>
                  <CardDescription className="text-[12px]">AI is online and ready to help</CardDescription>
                </div>
              </div>
            </CardHeader>

            {/* Messages */}
            <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${
                    message.role === "user" ? "justify-end" : "justify-start"
                  }`}
                >
                  {message.role === "assistant" && (
                    <div className="w-8 h-8 bg-gradient-to-br from-secondary to-primary rounded-full flex items-center justify-center flex-shrink-0">
                      <Sparkles className="w-4 h-4 text-white" />
                    </div>
                  )}
                  <div
                    className={`max-w-[75%] rounded-lg p-3 ${
                      message.role === "user"
                        ? "bg-primary text-white"
                        : "bg-muted text-foreground"
                    }`}
                  >
                    <p className="text-[14px] whitespace-pre-wrap">{message.content}</p>
                    <p
                      className={`text-[11px] mt-1 ${
                        message.role === "user" ? "text-white/70" : "text-muted-foreground"
                      }`}
                    >
                      {message.timestamp.toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  {message.role === "user" && (
                    <Avatar className="w-8 h-8 flex-shrink-0">
                      <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=Priya" />
                      <AvatarFallback>PS</AvatarFallback>
                    </Avatar>
                  )}
                </div>
              ))}

              {isTyping && (
                <div className="flex gap-3 justify-start">
                  <div className="w-8 h-8 bg-gradient-to-br from-secondary to-primary rounded-full flex items-center justify-center flex-shrink-0">
                    <Sparkles className="w-4 h-4 text-white" />
                  </div>
                  <div className="bg-muted rounded-lg p-3">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" />
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce [animation-delay:0.2s]" />
                      <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce [animation-delay:0.4s]" />
                    </div>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </CardContent>

            {/* Input Area */}
            <div className="border-t p-4">
              <div className="flex gap-2">
                <Input
                  placeholder="Ask me anything about fitness, nutrition, or wellness..."
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="flex-1"
                />
                <Button
                  size="icon"
                  className="bg-primary hover:bg-primary/90"
                  onClick={() => handleSendMessage()}
                  disabled={!inputMessage.trim() || isTyping}
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-[11px] text-muted-foreground mt-2">
                Press Enter to send, Shift + Enter for new line
              </p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
