import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../components/ui/select";
import { Badge } from "../components/ui/badge";
import { User, Heart, Activity, AlertCircle, Save, CheckCircle2 } from "lucide-react";

export function HealthProfile() {
  const [saved, setSaved] = useState(false);
  const [formData, setFormData] = useState({
    age: "28",
    height: "165",
    weight: "70",
    gender: "female",
    fitnessLevel: "intermediate",
    goal: "weight-loss",
    healthConditions: "None",
    allergies: "Dairy, Nuts",
    dietPreference: "vegetarian",
    activityLevel: "moderate",
    sleepHours: "7",
    waterIntake: "8",
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setSaved(false);
  };

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const bmi = (parseFloat(formData.weight) / Math.pow(parseFloat(formData.height) / 100, 2)).toFixed(1);
  const idealWeight = (22 * Math.pow(parseFloat(formData.height) / 100, 2)).toFixed(1);

  return (
    <div className="p-6 space-y-6 max-w-[1200px] mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[24px] font-semibold">Health Profile</h1>
          <p className="text-muted-foreground text-[14px]">
            Manage your personal health information for personalized recommendations
          </p>
        </div>
        <Button
          onClick={handleSave}
          className="bg-primary hover:bg-primary/90 gap-2"
          disabled={saved}
        >
          {saved ? (
            <>
              <CheckCircle2 className="w-4 h-4" />
              Saved!
            </>
          ) : (
            <>
              <Save className="w-4 h-4" />
              Save Profile
            </>
          )}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Overview */}
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-[16px]">
                <User className="w-5 h-5 text-primary" />
                Profile Summary
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center py-4">
                <div className="w-24 h-24 bg-gradient-to-br from-primary to-secondary rounded-full mx-auto mb-3 flex items-center justify-center">
                  <User className="w-12 h-12 text-white" />
                </div>
                <h3 className="font-semibold">Priya Sharma</h3>
                <p className="text-[12px] text-muted-foreground">priya.sharma@example.com</p>
              </div>
              <div className="space-y-2 pt-4 border-t">
                <div className="flex justify-between text-[13px]">
                  <span className="text-muted-foreground">Age</span>
                  <span className="font-medium">{formData.age} years</span>
                </div>
                <div className="flex justify-between text-[13px]">
                  <span className="text-muted-foreground">Height</span>
                  <span className="font-medium">{formData.height} cm</span>
                </div>
                <div className="flex justify-between text-[13px]">
                  <span className="text-muted-foreground">Weight</span>
                  <span className="font-medium">{formData.weight} kg</span>
                </div>
                <div className="flex justify-between text-[13px]">
                  <span className="text-muted-foreground">BMI</span>
                  <span className="font-medium">{bmi}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-[16px]">
                <Activity className="w-5 h-5 text-secondary" />
                Health Metrics
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="p-3 bg-primary/10 rounded-lg">
                <p className="text-[12px] text-muted-foreground">BMI Status</p>
                <p className="text-[16px] font-semibold text-primary">Normal</p>
              </div>
              <div className="p-3 bg-secondary/10 rounded-lg">
                <p className="text-[12px] text-muted-foreground">Ideal Weight</p>
                <p className="text-[16px] font-semibold text-secondary">{idealWeight} kg</p>
              </div>
              <div className="p-3 bg-accent/10 rounded-lg">
                <p className="text-[12px] text-muted-foreground">Daily Calorie Target</p>
                <p className="text-[16px] font-semibold text-accent">1800 kcal</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Profile Forms */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Information */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
              <CardDescription>Your fundamental health metrics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    value={formData.age}
                    onChange={(e) => handleInputChange("age", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gender">Gender</Label>
                  <Select value={formData.gender} onValueChange={(value) => handleInputChange("gender", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="height">Height (cm)</Label>
                  <Input
                    id="height"
                    type="number"
                    value={formData.height}
                    onChange={(e) => handleInputChange("height", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="weight">Weight (kg)</Label>
                  <Input
                    id="weight"
                    type="number"
                    value={formData.weight}
                    onChange={(e) => handleInputChange("weight", e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Fitness Information */}
          <Card>
            <CardHeader>
              <CardTitle>Fitness & Goals</CardTitle>
              <CardDescription>Your fitness level and objectives</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="fitnessLevel">Current Fitness Level</Label>
                  <Select value={formData.fitnessLevel} onValueChange={(value) => handleInputChange("fitnessLevel", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner</SelectItem>
                      <SelectItem value="intermediate">Intermediate</SelectItem>
                      <SelectItem value="advanced">Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="goal">Primary Goal</Label>
                  <Select value={formData.goal} onValueChange={(value) => handleInputChange("goal", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weight-loss">Weight Loss</SelectItem>
                      <SelectItem value="muscle-gain">Muscle Gain</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                      <SelectItem value="endurance">Build Endurance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="activityLevel">Activity Level</Label>
                  <Select value={formData.activityLevel} onValueChange={(value) => handleInputChange("activityLevel", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sedentary">Sedentary (little/no exercise)</SelectItem>
                      <SelectItem value="light">Light (1-3 days/week)</SelectItem>
                      <SelectItem value="moderate">Moderate (3-5 days/week)</SelectItem>
                      <SelectItem value="active">Active (6-7 days/week)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dietPreference">Diet Preference</Label>
                  <Select value={formData.dietPreference} onValueChange={(value) => handleInputChange("dietPreference", value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="vegetarian">Vegetarian</SelectItem>
                      <SelectItem value="vegan">Vegan</SelectItem>
                      <SelectItem value="non-vegetarian">Non-Vegetarian</SelectItem>
                      <SelectItem value="pescatarian">Pescatarian</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Health Conditions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-destructive" />
                Health Conditions & Allergies
              </CardTitle>
              <CardDescription>Important medical information for personalized plans</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="healthConditions">Health Conditions</Label>
                <Textarea
                  id="healthConditions"
                  placeholder="List any chronic conditions, injuries, or medical concerns..."
                  value={formData.healthConditions}
                  onChange={(e) => handleInputChange("healthConditions", e.target.value)}
                  className="min-h-[100px]"
                />
                <p className="text-[12px] text-muted-foreground">
                  e.g., Diabetes, Hypertension, Knee injury, etc.
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="allergies">Food Allergies</Label>
                <Textarea
                  id="allergies"
                  placeholder="List any food allergies or intolerances..."
                  value={formData.allergies}
                  onChange={(e) => handleInputChange("allergies", e.target.value)}
                  className="min-h-[80px]"
                />
                <p className="text-[12px] text-muted-foreground">
                  e.g., Dairy, Gluten, Nuts, Shellfish, etc.
                </p>
              </div>
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg flex gap-2">
                <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <p className="text-[12px] text-amber-800">
                  This information helps AROMI provide safe and personalized recommendations. Always consult with healthcare professionals before starting any new fitness or nutrition program.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Lifestyle Factors */}
          <Card>
            <CardHeader>
              <CardTitle>Lifestyle Factors</CardTitle>
              <CardDescription>Daily habits that affect your wellness</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sleepHours">Average Sleep (hours/night)</Label>
                  <Input
                    id="sleepHours"
                    type="number"
                    value={formData.sleepHours}
                    onChange={(e) => handleInputChange("sleepHours", e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="waterIntake">Daily Water Intake (glasses)</Label>
                  <Input
                    id="waterIntake"
                    type="number"
                    value={formData.waterIntake}
                    onChange={(e) => handleInputChange("waterIntake", e.target.value)}
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 pt-2">
                <Badge variant="secondary" className="justify-center py-2">
                  🏃 {formData.activityLevel}
                </Badge>
                <Badge variant="secondary" className="justify-center py-2">
                  🥗 {formData.dietPreference}
                </Badge>
                <Badge variant="secondary" className="justify-center py-2">
                  🎯 {formData.goal.replace("-", " ")}
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
