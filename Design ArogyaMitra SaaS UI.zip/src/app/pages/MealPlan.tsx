import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { MealItem } from "../components/shared/ProgressComponents";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { CheckCircle2, ChefHat, BookOpen } from "lucide-react";
import { Button } from "../components/ui/button";

interface Meal {
  id: string;
  type: string;
  name: string;
  description: string;
  calories: number;
}

interface DayMeal {
  day: number;
  totalCalories: number;
  meals: Meal[];
}

const weeklyMeals: DayMeal[] = [
  {
    day: 1,
    totalCalories: 1800,
    meals: [
      { id: "1-breakfast", type: "Breakfast", name: "Oats with Fruits", description: "Rolled oats, banana, berries, honey", calories: 350 },
      { id: "1-lunch", type: "Lunch", name: "Grilled Chicken Salad", description: "Mixed greens, chicken breast, olive oil", calories: 520 },
      { id: "1-snack", type: "Snack", name: "Greek Yogurt", description: "Low-fat yogurt with nuts", calories: 180 },
      { id: "1-dinner", type: "Dinner", name: "Salmon with Vegetables", description: "Baked salmon, broccoli, quinoa", calories: 580 },
      { id: "1-evening", type: "Evening Snack", name: "Herbal Tea & Almonds", description: "Green tea, 10 almonds", calories: 170 },
    ],
  },
  {
    day: 2,
    totalCalories: 1850,
    meals: [
      { id: "2-breakfast", type: "Breakfast", name: "Egg White Omelette", description: "3 egg whites, spinach, tomatoes, whole wheat toast", calories: 320 },
      { id: "2-lunch", type: "Lunch", name: "Dal + Brown Rice", description: "Moong dal, brown rice, cucumber salad", calories: 480 },
      { id: "2-snack", type: "Snack", name: "Apple with Peanut Butter", description: "1 apple, 1 tbsp peanut butter", calories: 200 },
      { id: "2-dinner", type: "Dinner", name: "Paneer Tikka + Roti", description: "Grilled paneer, 2 rotis, mint chutney", calories: 550 },
      { id: "2-evening", type: "Evening Snack", name: "Protein Shake", description: "Whey protein, banana, almond milk", calories: 300 },
    ],
  },
  {
    day: 3,
    totalCalories: 1780,
    meals: [
      { id: "3-breakfast", type: "Breakfast", name: "Smoothie Bowl", description: "Mixed berries, spinach, protein powder, granola", calories: 380 },
      { id: "3-lunch", type: "Lunch", name: "Chickpea Curry + Rice", description: "Chana masala, basmati rice, salad", calories: 500 },
      { id: "3-snack", type: "Snack", name: "Cottage Cheese", description: "Low-fat paneer with herbs", calories: 150 },
      { id: "3-dinner", type: "Dinner", name: "Grilled Fish + Veggies", description: "White fish, roasted vegetables", calories: 520 },
      { id: "3-evening", type: "Evening Snack", name: "Dark Chocolate", description: "85% cocoa, 2 squares", calories: 230 },
    ],
  },
  {
    day: 4,
    totalCalories: 1900,
    meals: [
      { id: "4-breakfast", type: "Breakfast", name: "Poha", description: "Flattened rice, peanuts, vegetables", calories: 340 },
      { id: "4-lunch", type: "Lunch", name: "Rajma + Rice", description: "Kidney beans curry, brown rice, raita", calories: 550 },
      { id: "4-snack", type: "Snack", name: "Mixed Nuts", description: "Almonds, walnuts, cashews", calories: 200 },
      { id: "4-dinner", type: "Dinner", name: "Chicken Stir Fry", description: "Chicken breast, bell peppers, brown rice", calories: 560 },
      { id: "4-evening", type: "Evening Snack", name: "Green Tea & Biscuits", description: "2 digestive biscuits", calories: 250 },
    ],
  },
  {
    day: 5,
    totalCalories: 1820,
    meals: [
      { id: "5-breakfast", type: "Breakfast", name: "Idli + Sambar", description: "4 idlis, sambar, coconut chutney", calories: 360 },
      { id: "5-lunch", type: "Lunch", name: "Palak Paneer + Roti", description: "Spinach paneer, 2 rotis, salad", calories: 530 },
      { id: "5-snack", type: "Snack", name: "Fruit Salad", description: "Mixed seasonal fruits", calories: 180 },
      { id: "5-dinner", type: "Dinner", name: "Tofu Stir Fry", description: "Tofu, vegetables, quinoa", calories: 500 },
      { id: "5-evening", type: "Evening Snack", name: "Roasted Chickpeas", description: "Spiced roasted chana", calories: 250 },
    ],
  },
  {
    day: 6,
    totalCalories: 2100,
    meals: [
      { id: "6-breakfast", type: "Breakfast", name: "Pancakes", description: "Whole wheat pancakes, maple syrup, berries", calories: 420 },
      { id: "6-lunch", type: "Lunch", name: "Chicken Biryani", description: "Brown rice biryani, raita, salad", calories: 650 },
      { id: "6-snack", type: "Snack", name: "Hummus with Veggies", description: "Chickpea hummus, carrot sticks, cucumber", calories: 220 },
      { id: "6-dinner", type: "Dinner", name: "Grilled Prawns", description: "Tiger prawns, grilled vegetables", calories: 580 },
      { id: "6-evening", type: "Evening Snack", name: "Protein Bar", description: "High-protein granola bar", calories: 230 },
    ],
  },
  {
    day: 7,
    totalCalories: 1880,
    meals: [
      { id: "7-breakfast", type: "Breakfast", name: "Masala Dosa", description: "1 dosa, potato filling, chutney", calories: 380 },
      { id: "7-lunch", type: "Lunch", name: "Vegetable Pulao", description: "Mixed vegetable rice, raita, papad", calories: 510 },
      { id: "7-snack", type: "Snack", name: "Sprouts Salad", description: "Moong sprouts, lemon dressing", calories: 170 },
      { id: "7-dinner", type: "Dinner", name: "Dal Tadka + Roti", description: "Yellow dal, 2 rotis, stir-fried veggies", calories: 520 },
      { id: "7-evening", type: "Evening Snack", name: "Herbal Tea & Dates", description: "Chamomile tea, 3 dates", calories: 300 },
    ],
  },
];

export function MealPlan() {
  const [mealCompletions, setMealCompletions] = useState<Record<string, boolean>>({});

  const toggleMeal = (mealId: string) => {
    setMealCompletions((prev) => ({
      ...prev,
      [mealId]: !prev[mealId],
    }));
  };

  const getDayCompletion = (day: DayMeal) => {
    const completed = day.meals.filter((meal) => mealCompletions[meal.id]).length;
    const consumedCalories = day.meals
      .filter((meal) => mealCompletions[meal.id])
      .reduce((sum, meal) => sum + meal.calories, 0);
    return { completed, total: day.meals.length, consumedCalories };
  };

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-[24px] font-semibold">7-Day Meal Plan</h1>
          <p className="text-muted-foreground text-[14px]">
            Balanced nutrition plan customized for your dietary preferences
          </p>
        </div>
        <Card className="md:w-auto bg-gradient-to-br from-accent to-destructive text-white border-none">
          <CardContent className="p-4 flex items-center gap-3">
            <ChefHat className="w-8 h-8" />
            <div>
              <p className="text-[20px] font-semibold">13,230 kcal</p>
              <p className="text-[12px] opacity-90">Weekly Target</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-accent" />
            Weekly Meal Overview
          </CardTitle>
          <CardDescription>Track your nutrition across the week</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-7 gap-2">
            {weeklyMeals.map((day) => {
              const { completed, total, consumedCalories } = getDayCompletion(day);
              const isCompleted = completed === total;
              return (
                <div
                  key={day.day}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    isCompleted
                      ? "bg-accent/10 border-accent"
                      : "bg-white border-border hover:border-accent/40"
                  }`}
                >
                  <div className="text-center">
                    <p className="text-[11px] text-muted-foreground font-medium">Day {day.day}</p>
                    {isCompleted && <CheckCircle2 className="w-6 h-6 text-accent mx-auto mt-1" />}
                    {!isCompleted && (
                      <div className="mt-1">
                        <p className="text-[14px] font-semibold">{consumedCalories}</p>
                        <p className="text-[10px] text-muted-foreground">/{day.totalCalories}</p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Meal Days */}
      <Tabs defaultValue="1" className="w-full">
        <TabsList className="w-full justify-start overflow-x-auto flex-wrap h-auto">
          {weeklyMeals.map((day) => {
            const { completed, total } = getDayCompletion(day);
            const isCompleted = completed === total;
            return (
              <TabsTrigger key={day.day} value={day.day.toString()} className="relative">
                Day {day.day}
                {isCompleted && (
                  <CheckCircle2 className="w-4 h-4 text-accent absolute -top-1 -right-1" />
                )}
              </TabsTrigger>
            );
          })}
        </TabsList>

        {weeklyMeals.map((day) => {
          const { completed, total, consumedCalories } = getDayCompletion(day);
          return (
            <TabsContent key={day.day} value={day.day.toString()} className="space-y-4 mt-6">
              <Card>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-[18px]">Day {day.day} Nutrition</CardTitle>
                      <CardDescription>
                        Target: {day.totalCalories} kcal | Consumed: {consumedCalories} kcal
                      </CardDescription>
                    </div>
                    <Badge
                      variant={completed === total ? "default" : "secondary"}
                      className={completed === total ? "bg-accent" : ""}
                    >
                      {completed} / {total} Meals
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {day.meals.map((meal) => (
                    <MealItem
                      key={meal.id}
                      meal={`${meal.type} – ${meal.name}`}
                      description={meal.description}
                      calories={meal.calories}
                      completed={!!mealCompletions[meal.id]}
                      onToggle={() => toggleMeal(meal.id)}
                    />
                  ))}

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-6">
                    <Card className="bg-primary/5 border-primary/20">
                      <CardContent className="p-4 text-center">
                        <p className="text-[20px] font-semibold text-primary">
                          {consumedCalories}
                        </p>
                        <p className="text-[12px] text-muted-foreground">Consumed Calories</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-accent/5 border-accent/20">
                      <CardContent className="p-4 text-center">
                        <p className="text-[20px] font-semibold text-accent">
                          {day.totalCalories - consumedCalories}
                        </p>
                        <p className="text-[12px] text-muted-foreground">Remaining Calories</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-secondary/5 border-secondary/20">
                      <CardContent className="p-4 text-center">
                        <p className="text-[20px] font-semibold text-secondary">
                          {Math.round((consumedCalories / day.totalCalories) * 100)}%
                        </p>
                        <p className="text-[12px] text-muted-foreground">Daily Progress</p>
                      </CardContent>
                    </Card>
                  </div>

                  {completed === total && (
                    <div className="mt-6 p-4 bg-accent/10 border border-accent/20 rounded-lg flex items-center gap-3">
                      <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
                        <ChefHat className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-semibold text-accent">Day {day.day} Nutrition Complete!</p>
                        <p className="text-[13px] text-muted-foreground">
                          Excellent work on following your meal plan today.
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          );
        })}
      </Tabs>
    </div>
  );
}
