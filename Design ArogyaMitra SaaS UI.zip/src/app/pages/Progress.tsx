import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Badge } from "../components/ui/badge";
import { TrendingUp, TrendingDown, Flame, Target, Award, Calendar } from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const weightData = [
  { week: "Week 1", weight: 72, goal: 70 },
  { week: "Week 2", weight: 71.5, goal: 70 },
  { week: "Week 3", weight: 71, goal: 70 },
  { week: "Week 4", weight: 70.5, goal: 70 },
  { week: "Week 5", weight: 70.2, goal: 70 },
  { week: "Week 6", weight: 70, goal: 70 },
];

const caloriesData = [
  { date: "Mon", burned: 420, consumed: 1800, target: 1800 },
  { date: "Tue", burned: 380, consumed: 1950, target: 1800 },
  { date: "Wed", burned: 450, consumed: 1850, target: 1800 },
  { date: "Thu", burned: 390, consumed: 1900, target: 1800 },
  { date: "Fri", burned: 410, consumed: 1820, target: 1800 },
  { date: "Sat", burned: 520, consumed: 2100, target: 1800 },
  { date: "Sun", burned: 480, consumed: 1880, target: 1800 },
];

const workoutCompletionData = [
  { week: "Week 1", completed: 5, total: 7 },
  { week: "Week 2", completed: 6, total: 7 },
  { week: "Week 3", completed: 7, total: 7 },
  { week: "Week 4", completed: 6, total: 7 },
];

const activityData = [
  { day: "Mon", steps: 8500, active: 45, calories: 420 },
  { day: "Tue", steps: 7200, active: 38, calories: 380 },
  { day: "Wed", steps: 9800, active: 52, calories: 450 },
  { day: "Thu", steps: 7800, active: 41, calories: 390 },
  { day: "Fri", steps: 8200, active: 43, calories: 410 },
  { day: "Sat", steps: 12000, active: 68, calories: 520 },
  { day: "Sun", steps: 10500, active: 58, calories: 480 },
];

const achievements = [
  { icon: "🏅", title: "7 Day Streak", description: "Completed workouts for 7 consecutive days", date: "Mar 7, 2026", color: "bg-accent" },
  { icon: "💪", title: "10 Workouts", description: "Finished 10 workout sessions", date: "Mar 5, 2026", color: "bg-primary" },
  { icon: "🥗", title: "5 Healthy Days", description: "Stayed within calorie goals for 5 days", date: "Mar 6, 2026", color: "bg-secondary" },
  { icon: "🎯", title: "Goal Weight", description: "Reached your target weight of 70kg", date: "Mar 8, 2026", color: "bg-destructive" },
  { icon: "⚡", title: "5000 Calories", description: "Burned 5000 calories this week", date: "Mar 4, 2026", color: "bg-chart-4" },
  { icon: "📈", title: "30 Day Active", description: "Logged activity for 30 days", date: "Mar 1, 2026", color: "bg-chart-5" },
];

export function Progress() {
  const currentWeight = 70;
  const startWeight = 72;
  const weightLost = startWeight - currentWeight;
  const weeklyStreak = 7;
  const totalWorkouts = 24;
  const avgCalories = 1886;

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div>
        <h1 className="text-[24px] font-semibold">Progress Tracking</h1>
        <p className="text-muted-foreground text-[14px]">
          Monitor your fitness journey and celebrate your achievements
        </p>
      </div>

      {/* Key Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-primary to-primary/70 text-white border-none">
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[13px] opacity-90">Weight Lost</p>
                <p className="text-[28px] font-semibold mt-1">{weightLost} kg</p>
                <div className="flex items-center gap-1 mt-2">
                  <TrendingDown className="w-4 h-4" />
                  <span className="text-[12px]">From {startWeight}kg to {currentWeight}kg</span>
                </div>
              </div>
              <Target className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-accent to-accent/70 text-white border-none">
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[13px] opacity-90">Current Streak</p>
                <p className="text-[28px] font-semibold mt-1">{weeklyStreak} Days</p>
                <div className="flex items-center gap-1 mt-2">
                  <Flame className="w-4 h-4" />
                  <span className="text-[12px]">Keep it going!</span>
                </div>
              </div>
              <Flame className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-secondary to-secondary/70 text-white border-none">
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[13px] opacity-90">Total Workouts</p>
                <p className="text-[28px] font-semibold mt-1">{totalWorkouts}</p>
                <div className="flex items-center gap-1 mt-2">
                  <TrendingUp className="w-4 h-4" />
                  <span className="text-[12px]">This month</span>
                </div>
              </div>
              <Award className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-chart-4 to-chart-4/70 text-white border-none">
          <CardContent className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[13px] opacity-90">Avg Calories</p>
                <p className="text-[28px] font-semibold mt-1">{avgCalories}</p>
                <div className="flex items-center gap-1 mt-2">
                  <Calendar className="w-4 h-4" />
                  <span className="text-[12px]">Per day</span>
                </div>
              </div>
              <Target className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weight Progress */}
        <Card>
          <CardHeader>
            <CardTitle>Weight Progress</CardTitle>
            <CardDescription>6-week weight tracking journey</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={weightData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="week" tick={{ fontSize: 12 }} />
                <YAxis domain={[68, 73]} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="weight"
                  stroke="#10b981"
                  strokeWidth={3}
                  dot={{ fill: "#10b981", r: 5 }}
                  name="Current Weight"
                />
                <Line
                  type="monotone"
                  dataKey="goal"
                  stroke="#f97316"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={false}
                  name="Goal Weight"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Calories Tracking */}
        <Card>
          <CardHeader>
            <CardTitle>Calories Tracking</CardTitle>
            <CardDescription>Burned vs consumed this week</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={caloriesData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="burned" fill="#10b981" radius={[8, 8, 0, 0]} name="Burned" />
                <Bar dataKey="consumed" fill="#60a5fa" radius={[8, 8, 0, 0]} name="Consumed" />
                <Bar dataKey="target" fill="#f97316" radius={[8, 8, 0, 0]} name="Target" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Workout Completion Rate */}
        <Card>
          <CardHeader>
            <CardTitle>Workout Completion Rate</CardTitle>
            <CardDescription>Weekly workout adherence</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={workoutCompletionData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="week" tick={{ fontSize: 12 }} />
                <YAxis domain={[0, 7]} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="completed" fill="#10b981" radius={[8, 8, 0, 0]} name="Completed" />
                <Bar dataKey="total" fill="#e5e7eb" radius={[8, 8, 0, 0]} name="Total" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Daily Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Daily Activity</CardTitle>
            <CardDescription>Steps and active minutes this week</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="day" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="steps"
                  stroke="#60a5fa"
                  fill="#60a5fa"
                  fillOpacity={0.3}
                  name="Steps"
                />
                <Area
                  type="monotone"
                  dataKey="active"
                  stroke="#10b981"
                  fill="#10b981"
                  fillOpacity={0.3}
                  name="Active Minutes"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Achievements */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Award className="w-5 h-5 text-accent" />
            Your Achievements
          </CardTitle>
          <CardDescription>Milestones you've unlocked on your wellness journey</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {achievements.map((achievement, index) => (
              <div
                key={index}
                className="p-4 rounded-lg border border-border hover:border-primary/40 transition-all bg-white"
              >
                <div className="flex items-start gap-3">
                  <div className={`w-12 h-12 ${achievement.color} rounded-full flex items-center justify-center text-[24px]`}>
                    {achievement.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-[14px]">{achievement.title}</h3>
                    <p className="text-[12px] text-muted-foreground mt-1">
                      {achievement.description}
                    </p>
                    <Badge variant="secondary" className="mt-2 text-[10px]">
                      {achievement.date}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
